export const tempstate = {
	notifications: [
		{
		  month: "July",
		  date: "22",
		  author: "Irene",
		  action: "update",
		  project: "You Neek, Clothing Store",
		  read: false,
		},
	
		{
		  month: "July",
		  date: "18",
		  author: "Gerald",
		  action: "accepted",
		  project: "Meat Cutters, Employee Tracker",
		  read: false,
		},
	
		{
		  month: "July",
		  date: "17",
		  project: "ProMatches",
		  author: "Justin Durk",
		  action: "completed",
		  read: true,
		},
		{
		  month: "July",
		  date: "13",
		  author: "Morty Sanchez",
		  action: "cancelled",
		  project: "Time travel app",
		  read: true,
		},
		{
		  month: "July",
		  date: "12",
		  author: "Rick Sanchez",
		  action: "completed",
		  project: "spaceship tracker",
		  read: true,
		},
		{
			month: "Feb",
			date: "18",
			author: "Gordon Ramsayyy",
			action: "completed",
			project: "Restraunt order maker",
			read: true,
		},
		{
			month: "Feb",
			date: "18",
			author: "Gordon Ramsayyy",
			action: "completed",
			project: "Restraunt order maker",
			read: true,
		},
		{
			month: "Feb",
			date: "18",
			author: "Gordon Ramsayyy",
			action: "completed",
			project: "Restraunt order maker",
			read: true,
		},
		{
			month: "Feb",
			date: "18",
			author: "Gordon Ramsayyy",
			action: "completed",
			project: "Restraunt order maker",
			read: true,
		},
	  ]
}
