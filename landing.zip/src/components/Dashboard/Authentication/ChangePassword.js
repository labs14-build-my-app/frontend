import React, { Component } from 'react';

class ChangePassword extends Component {
	render() { 
		return (
			<div>
				changes your god damn password. Youre gonna have to back arrow because i havent setup the page properly yet
			</div>
		);
	}
}
 
export default ChangePassword;
